/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fr.ufrsciencestech.fonctionnal;

/**
 *
 * @author fatima
 */

import fr.ufrsciencestech.animalerie.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class Connexion {


    
}
