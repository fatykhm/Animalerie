package fr.ufrsciencestech.fonctionnal;

import fr.ufrsciencestech.animalerie.User;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class Inscription {

   
}
